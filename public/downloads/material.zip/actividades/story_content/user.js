function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6qE6m1KQIcw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

